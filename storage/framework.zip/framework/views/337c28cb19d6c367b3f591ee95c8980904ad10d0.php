<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Patient一覧表示</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #f2f2f2;
            padding: 10px 20px;
            border-bottom: 2px solid #ccc;
        }

        .header-left h1 {
            margin: 0;
            font-size: 1.8rem;
            color: #333;
        }

        .header-right {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .header-right a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }

        .header-right a:hover {
            text-decoration: underline;
        }

        .header-right form {
            margin: 0;
        }

        .room-container {
            border: 2px solid #333;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 30px;
        }
        .room-title {
            font-size: 1.4rem;
            font-weight: bold;
            margin-bottom: 15px;
            color: #1a1a1a;
        }
        .patients-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        .patient-card {
            border: 1px solid #aaa;
            border-radius: 6px;
            padding: 10px;
            background-color: #fafafa;
            box-shadow: 1px 1px 4px rgba(0,0,0,0.1);
        }
        .patient-card a {
            font-weight: bold;
            text-decoration: none;
            color: #0066cc;
        }
        .patient-card a:hover {
            text-decoration: underline;
        }
        form {
            margin-top: 10px;
        }
        form button {
            background-color: #007bff;
            border: none;
            padding: 6px 10px;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }
        form button:hover {
            background-color: #0056b3;
        }
        /* スケジュール情報 */
        .schedule-info {
            margin-top: 10px;
            font-size: 0.9rem;
            color: #333;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
        .schedule-section {
            margin-bottom: 8px;
        }
    </style>
</head>

<body>
    <header>
        <div class="header-left">
            <h1>10F病棟</h1>
        </div>
    
        <div class="header-right">
            <a href="<?php echo e(route('patient.register')); ?>">患者を追加</a>
    
            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomPatients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $roomPatients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstPatient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('assigned.index',['pt_id' => $firstPatient->pt_id])); ?>">My患者</a>
                    <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php break; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit">ログアウト</button>
            </form>
        </div>
    </header>
    

    <div>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room_id => $roomPatients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="room-container">
                <div class="room-title">100<?php echo e($room_id); ?>号室</div>

                <div class="patients-grid">
                    <?php $__currentLoopData = $roomPatients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="patient-card">
                            <a href="<?php echo e(route('patient.information', $patient->pt_id)); ?>">
                                👤 <?php echo e($patient->pt_name); ?>

                            </a>

                            <div><?php echo e($patient->disease->disease_name); ?></div>

                            
                            <form action="<?php echo e(route('assigned.add', $patient->pt_id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit">My患者追加</button>
                            </form>

                            
                            <div class="schedule-info">
                                <?php $__empty_1 = true; $__currentLoopData = $patient->ptSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="schedule-section">
                                        <div>スケジュールID: <?php echo e($schedule->pt_schedule_id ?? '未設定'); ?></div>

                                        
                                        <?php $__currentLoopData = $schedule->dialysis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dialysis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div>
                                                部位: <?php echo e(optional($dialysis->dialysisMaster)->part ?? '未設定'); ?>,
                                                日: <?php echo e(optional($dialysis->dialysisMaster)->dialysis_day ?? '未設定'); ?>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <?php $__currentLoopData = $schedule->treatmentkind; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div>
                                                治療: <?php echo e(optional($treatment->treatmentkindMaster)->value ?? '未設定'); ?>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <?php $__currentLoopData = $schedule->carekind; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $care): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div>
                                                ケア: <?php echo e(optional($care->carekindMaster)->value ?? '未設定'); ?>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <div>
                                            <?php $__currentLoopData = $schedule->meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                                    食事: <?php echo e($meal->food_name ?? '未設定'); ?><br>
                                                    形態: <?php echo e($meal->food_form ?? '未設定'); ?>                                   
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                        
                                        <?php if(\Carbon\Carbon::parse($schedule->daily_schedule_date)->isSameDay(\Carbon\Carbon::parse($today))): ?>
                                            <div>薬の数: <?php echo e($schedule->medicines->count()); ?></div>
                                            <?php $__currentLoopData = $schedule->medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tMedicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    薬: <?php echo e(optional($tMedicine->medicineMaster)->drug_name ?? '未設定'); ?><br>
                                                    用法: <?php echo e(optional($tMedicine->medicineMaster)->usage ?? '未設定'); ?><br>
                                                    用量: <?php echo e(optional($tMedicine->medicineMaster)->dose ?? '未設定'); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div>スケジュールなし</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>

</html>
<?php /**PATH /Users/masuyahayato/Desktop/schedule-app/resources/views/patient/index.blade.php ENDPATH**/ ?>