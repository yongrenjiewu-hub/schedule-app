<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>食事情報</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fff;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            width: 100%;
            background-color: #f2f2f2;
            padding: 15px 30px;
            border-bottom: 2px solid #ccc;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-sizing: border-box;
        }

        .header-left h1 {
            margin: 0;
            font-size: 1.5rem;
            color: #333;
        }

        .header-right a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }

        .header-right a:hover {
            text-decoration: underline;
        }

        main {
            width: 100%;
            max-width: 600px;
            background: #fafafa;
            padding: 30px 40px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-sizing: border-box;
            margin-top: 30px;
        }

        h2 {
            text-align: center;
            color: #444;
            margin-bottom: 20px;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li.meal-item {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
            background-color: #fff;
            margin-bottom: 10px;
            border-radius: 5px;
            box-shadow: 0 0 3px rgba(0,0,0,0.1);
        }

        .no-data {
            text-align: center;
            color: #999;
            font-style: italic;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

<header>
    <div class="header-left">
        <h1><?php echo e($patient->pt_name ?? '患者名不明'); ?> の食事情報</h1>
    </div>
    <div class="header-right">
        <?php if(isset($patient)): ?>
            <a href="<?php echo e(route('patient.information', $patient->pt_id)); ?>">
                患者情報へ戻る
            </a>
        <?php endif; ?>
    </div>
</header>

<main>
    <h2>食事</h2>

    <?php if($patient): ?>
        <?php $__empty_1 = true; $__currentLoopData = $patient->ptSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($schedule->meals->isEmpty()): ?>
                <div class="no-data">食事なし（スケジュールID: <?php echo e($schedule->pt_schedule_id); ?>）</div>
            <?php else: ?>
                <div class="no-data">スケジュールID: <?php echo e($schedule->pt_schedule_id); ?></div>
                <ul>
                    <?php $__currentLoopData = $schedule->meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="meal-item">
                            食事: <?php echo e($meal->food_name ?? '未設定'); ?><br>
                            形態: <?php echo e($meal->food_form ?? '未設定'); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="no-data">スケジュールがありません。</div>
        <?php endif; ?>
    <?php else: ?>
        <div class="no-data">患者が選択されていません。</div>
    <?php endif; ?>

</main>

</body>
</html>
<?php /**PATH /Users/masuyahayato/Desktop/schedule-app/resources/views/meal/index.blade.php ENDPATH**/ ?>