<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>患者情報登録</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #fff;
            color: #333;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 2px solid #ccc;
            margin-bottom: 30px;
        }

        header h1 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: bold;
        }

        header a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
            font-size: 1rem;
        }

        header a:hover {
            text-decoration: underline;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fafafa;
            padding: 25px 30px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        form h3 {
            margin-bottom: 8px;
            font-weight: 600;
            color: #444;
        }

        select,
        input[type="text"],
        input[type="tel"],
        input[type="number"],
        input[type="hidden"] {
            width: 100%;
            padding: 8px 10px;
            margin-bottom: 18px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 1rem;
            color: #333;
        }

        select[multiple] {
            height: auto;
            min-height: 100px;
        }

        input[type="submit"] {
            background-color: #007bff;
            border: none;
            padding: 12px 25px;
            color: #fff;
            font-weight: bold;
            font-size: 1.1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            display: block;
            margin: 30px auto 0;
            width: 150px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        label {
            font-weight: 500;
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
    </style>
</head>

<body>
    <header>
        <h1>患者情報登録</h1>
        
        <?php if($m_patient->count() > 0): ?>
            <a href="<?php echo e(route('patient.information', $m_patient->first()->pt_id)); ?>">戻る</a>
        <?php endif; ?>
    </header>

    <form method="POST" action="<?php echo e(route('patient.update', $id)); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($id); ?>">

        <div>
            <h3>病気</h3>
            <select name="disease" required>
                <option value="">選択してください</option>
                <?php $__currentLoopData = $m_disease; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($disease->disease_id); ?>" 
                        <?php if(optional($m_patient->first())->disease_id == $disease->disease_id): ?> selected <?php endif; ?>>
                        <?php echo e($disease->disease_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <?php
            $allCareCategories = $t_care_kind->pluck('care_kind_id');
        ?>

        <div>
            <h3>看護ケア</h3>
            <?php $__currentLoopData = $m_care_kind; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $careKinds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label><?php echo e($category); ?> のケア種類を選択</label>
                <select name="care[<?php echo e($category); ?>]" >
                    <option value="">選択してください</option>
                    <?php $__currentLoopData = $careKinds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $care): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($care->care_kind_id); ?>" 
                            <?php if($allCareCategories->contains($care->care_kind_id)): ?> selected <?php endif; ?>>
                            <?php echo e($care->value); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        
        <?php
        // カテゴリ毎にグループ化している前提（$allTreatmentKinds に DBから全件のMTreatmentkindモデルが入っていると仮定）
        $TreatmentKinds = $allTreatmentKinds->groupBy('category');
    
        $categoryLabels = [
            'treatment' => '治療',
            'check' => '検査',
            'rehabilitation' => 'リハビリ',
            'operation' => '手術',
            'check_data' => 'データ',
            'その他' => 'その他',
        ];
    
        // 既に選択されている treatment_kind_id の配列
        $selectedIds = $selectedTreatmentKindIds ?? [];
        ?>
        
        <?php $__currentLoopData = $TreatmentKinds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h4><?php echo e($categoryLabels[$category] ?? $category); ?></h4>
            <ul>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <label>
                        <input type="checkbox" name="treatment[<?php echo e($category); ?>][]" value="<?php echo e($item->treatment_kind_id); ?>"
                            <?php echo e(in_array($item->treatment_kind_id, $selectedIds) ? 'checked' : ''); ?>>
                        <?php echo e($item->value); ?>

                    </label>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php
            $allDialysisParts = $t_pt_dialysis->pluck('t_pt_dialysis_part');
        ?>

        <div>
            <h3>透析</h3>
            <?php $__currentLoopData = $m_dialysis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dialysis => $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label><?php echo e($dialysis); ?></label>
                <select name="dialysis[<?php echo e($dialysis); ?>]" >
                    <option value="">選択してください</option>
                    <?php $__currentLoopData = $dia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($d->dialysis_id); ?>" 
                            <?php if($allDialysisParts->contains($d->dialysis_id)): ?> selected <?php endif; ?>>
                            <?php echo e($d->part); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <?php
        $uniqueMedicines = $m_medicine->unique('drug_name');
        ?>

        <div>
            <h3>薬</h3>
            <?php $__currentLoopData = $uniqueMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label>
                    <input type="checkbox" name="medicine[]" value="<?php echo e($medicine->medicine_id); ?>"
                    <?php echo e((is_array($selectedMedicineIds) && in_array((string)$medicine->medicine_id, array_map('strval', $selectedMedicineIds))) ? 'checked' : ''); ?>>

                    <?php echo e($medicine->drug_name); ?>

                </label><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div>
            <h3>食事</h3>
            <select name="meal[]" multiple>
                <?php $__currentLoopData = $m_meal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($meal->meal_id); ?>"
                        <?php if(in_array($meal->meal_id, $selectedMealIds ?? [])): ?> selected <?php endif; ?>>
                        <?php echo e($meal->food_name); ?> : <?php echo e($meal->food_form); ?> (<?php echo e($meal->food_time_label); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <input type="submit" value="登録">
    </form>
</body>

</html>
<?php /**PATH /Users/masuyahayato/Documents/schedule-app/resources/views/patient/add.blade.php ENDPATH**/ ?>