<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>スケジュール</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f6f8fa;
        }

        header {
            background-color: #007bff;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
            font-size: 1.5em;
        }

        header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        main {
            padding: 30px;
            max-width: 900px;
            margin: 0 auto;
        }

        .patient-section {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            text-align: center;
        }

        .patient-section h3 {
            margin-top: 0;
            color: #333;
        }

        ul {
            list-style-type: none;
            padding: 0;
            margin-top: 10px;
        }

        li {
            background-color: #f1f1f1;
            margin: 5px 0;
            padding: 10px;
            border-radius: 5px;
            text-align: left;
        }

        form {
            display: inline;
        }

        button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            margin-left: 10px;
            cursor: pointer;
        }

        button:hover {
            background-color: #c82333;
        }

        strong {
            display: block;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>

<header>
    <h1>スケジュール</h1>
    <a href="<?php echo e(route('assigned.index')); ?>">My患者へ</a>
</header>

<main>

    <?php $__currentLoopData = $assignedPatients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigned): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="patient-section">
        <h3><?php echo e($assigned->patient->pt_name); ?></h3>

        <?php $__currentLoopData = $assigned->patient->ptSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <strong><?php echo e(\Carbon\Carbon::parse($schedule->daily_schedule_date)->format('Y-m-d')); ?></strong>

                <ul>
                    <?php $__currentLoopData = $schedule->sortedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($item['label']); ?>: <?php echo e($item['value']); ?>（<?php echo e($item['time']); ?>）

                            <?php if(!empty($item['deleteRoute'])): ?>
                                <form method="POST" action="<?php echo e($item['deleteRoute']); ?>" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit">削除</button>
                                </form>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    
    
                    

                    
                    

                    
                    

                    
                    

                    
                    
</main>

</body>
</html>
<?php /**PATH /Users/masuyahayato/Desktop/schedule-app/resources/views/schedule/index.blade.php ENDPATH**/ ?>