<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My患者一覧</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background-color: #f9f9f9;
            padding: 10px 20px;
            border-bottom: 2px solid #ccc;
        }

        .header-left h1 {
            margin: 0;
            font-size: 1.8rem;
            color: #333;
        }

        .header-right {
            display: flex;
            gap: 20px;
            align-items: center;
        }

        .header-right a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }

        .header-right a:hover {
            text-decoration: underline;
        }

        .room-container {
            border: 2px solid #333;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 30px;
        }

        .room-title {
            font-size: 1.4rem;
            font-weight: bold;
            margin-bottom: 15px;
            color: #1a1a1a;
        }

        .patient-card {
            border: 1px solid #aaa;
            border-radius: 6px;
            padding: 10px;
            background-color: #fafafa;
            box-shadow: 1px 1px 4px rgba(0,0,0,0.1);
            margin-bottom: 15px;
        }

        .patient-card a {
            font-weight: bold;
            text-decoration: none;
            color: #0066cc;
        }

        .patient-card a:hover {
            text-decoration: underline;
        }

        form {
            margin-top: 10px;
        }

        form button {
            background-color: #007bff;
            border: none;
            padding: 6px 10px;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }

        form button:hover {
            background-color: #0056b3;
        }

        /* 横並びスタイル */
        .schedule-info {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 10px;
            font-size: 0.9rem;
            color: #333;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }

        .schedule-section {
            flex: 1 1 200px;
            background-color: #fff;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
        }

        .schedule-section h4 {
            margin: 0 0 5px;
            font-size: 1rem;
            color: #555;
        }

        @media (max-width: 768px) {
            .schedule-info {
                flex-direction: column;
            }

            .schedule-section {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<header>
    <div class="header-left">
        <h1>My患者一覧</h1>
    </div>

    <div class="header-right">
        <a href="<?php echo e(route('patient.index')); ?>">患者一覧に戻る</a>
        <a href="<?php echo e(route('schedule.index')); ?>">スケジュール</a>
    </div>
</header>

<?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomId => $patientsInRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="room-container">
        <div class="room-title">部屋 <?php echo e($roomId); ?></div>

        <?php $__empty_2 = true; $__currentLoopData = $patientsInRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
            <div class="patient-card">
                <a href="<?php echo e(route('patient.information', $patient->pt_id)); ?>">
                    👤 <?php echo e($patient->pt_name); ?>

                </a>
                <p>性別: <?php echo e($patient->sex); ?></p>
                <p>血液型: <?php echo e($patient->blood_type); ?></p>

                <div class="schedule-info">
                    <?php $__empty_3 = true; $__currentLoopData = $patient->ptSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                        <div class="schedule-section">
                            <h4>透析</h4>
                            <?php $__currentLoopData = $schedule->dialysis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>部位: <?php echo e(optional($d->dialysisMaster)->part ?? '未設定'); ?></div>
                                <div>日: <?php echo e(optional($d->dialysisMaster)->dialysis_day ?? '未設定'); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="schedule-section">
                            <h4>治療</h4>
                            <?php $__currentLoopData = $schedule->treatmentkind; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>項目: <?php echo e(optional($t->treatmentkindMaster)->value ?? '未設定'); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="schedule-section">
                            <h4>ケア</h4>
                            <?php $__currentLoopData = $schedule->carekind; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>項目: <?php echo e(optional($c->carekindMaster)->value ?? '未設定'); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="schedule-section">
                            <h4>食事</h4>
                                <?php $__currentLoopData = $schedule->meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                        食事: <?php echo e($meal->food_name ?? '未設定'); ?><br>
                                        形態: <?php echo e($meal->food_form ?? '未設定'); ?>                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <?php if(\Carbon\Carbon::parse($schedule->daily_schedule_date)->isSameDay(\Carbon\Carbon::parse($today))): ?>
                            <div class="schedule-section">
                                <h4>薬</h4>
                                <div>薬の数: <?php echo e($schedule->medicines->count()); ?></div>
                                <?php $__currentLoopData = $schedule->medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tMedicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>薬: <?php echo e(optional($tMedicine->medicineMaster)->drug_name ?? '未設定'); ?></div>
                                    <div>用法: <?php echo e(optional($tMedicine->medicineMaster)->usage ?? '未設定'); ?></div>
                                    <div>用量: <?php echo e(optional($tMedicine->medicineMaster)->dose ?? '未設定'); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                        <div>スケジュールなし</div>
                    <?php endif; ?>
                </div>

                <form method="POST" action="<?php echo e(route('assigned.remove', $patient->pt_id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">削除</button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
            <p>この部屋に患者はいません。</p>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>My患者は登録されていません。</p>
<?php endif; ?>

<script>
    const schedules = <?php echo json_encode($reminderSchedules, 15, 512) ?>;

    if (Notification.permission !== "granted") {
        Notification.requestPermission().then(permission => {
            if (permission === "granted") {
                setupReminders();
            }
        });
    } else {
        setupReminders();
    }

    function setupReminders() {
        const notifyBeforeMinutes = 5;
        const now = Date.now();

        schedules.forEach(schedule => {
            const scheduleTime = new Date(schedule.datetime).getTime();
            const notifyTime = scheduleTime - notifyBeforeMinutes * 60 * 1000;
            const delay = notifyTime - now;

            if (delay > 0) {
                setTimeout(() => {
                    new Notification("リマインダー", {
                        body: `患者 ${schedule.pt_name} の予定時間です：${schedule.datetime}`,
                    });
                }, delay);
            }
        });
    }
</script>

</body>
</html>
<?php /**PATH /Users/masuyahayato/Documents/schedule-app/resources/views/assigned/index.blade.php ENDPATH**/ ?>