<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TMealController extends Controller
{
    //
}
